const express = require("express");
var router = express.Router();
var AWS = require("aws-sdk");
var dynamoDb = new AWS.DynamoDB.DocumentClient();

var CUSTOMEPOCH = 1300000000000; 
function generateRowId(shardId) 
{
  var ts = new Date().getTime() - CUSTOMEPOCH; 
  var randid = Math.floor(Math.random() * 512);
  ts = (ts * 64);  
  ts = ts + shardId;
  return (ts * 512) + randid;
}
var newPrimaryHashKey = "" + generateRowId(4);


router.get('/', (req, res) => 
    {
        res.render('newpost', { "registered_email": req.session.registered_email });


    });
    



router.post('/', function (req, res, next) 
{
    console.log("Creando Producto");
    const { description } = req.body;
  
    console.log("description = " + description);


    
    const params = 
    {
        TableName: 'notes',
        Item: {
            noteId: newPrimaryHashKey,
            description: description,
        },
    };

    dynamoDb.put(params, (error) => 
    {
        if (error) 
        {
            console.log(error);
            res.status(400).json({error: 'No se pudo crear producto'});
        }
        console.log("Description " + description + " saved exitosamente.");
        res.redirect("/posts");
        
       
    });
   
});


  




module.exports = router;