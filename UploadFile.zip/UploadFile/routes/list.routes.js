const express = require("express");
var router = express.Router();
const {
  getFiles,
   
} = require('../auth/controlle_files');


router.get('/', async (req, res) => 
{
    try 
    {
        const files = await getFiles();
        var files2 = files.Contents;
        console.log(files2);
        res.render('list', {"registered_email": req.session.registered_email, files2 });


    } catch (err) 
    {
        console.error(err);
        res.status(500).json({ err: 'Something went wrong' });

       

    }
   
});






//  router.get("/delete", controller.delete);
  

// router.get('/', async (req, res, next) => 
// {
//     let url = 'https://photo-gallery-heroku.s3.us-east-2.amazonaws.com/';
//     let data;
//     let params = {
//         Bucket: 'photo-gallery-heroku',
//     }

//     try {
//         data = await S3.listObjectsV2(params).promise();
//     } catch (error) {
//         next(error);
//     }

//     res.render('index', { url, content: data.Contents });
// });

// router.get('/', (req, res) => 
// {
// res.render('list', { show_polls: polls } , { "registered_email": req.session.registered_email});


// });







    
    module.exports = router;