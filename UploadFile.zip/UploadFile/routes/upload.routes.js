const express = require("express");
var router = express.Router();
var aws = require('aws-sdk');
var multer = require('multer');
var multerS3 = require('multer-s3');

aws.config.update(
{
	accessKeyId: 'AKIAR57BUIFV3AW57GMS',
    secretAccessKey: '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',    
    region: 'us-east-1'
});

s3 = new aws.S3();
var upload = multer(
    {
    storage: multerS3({
        s3: s3,
        bucket: 'media-uploadfinal',
        key: function (req, file, cb) 
        {
            cb(null, file.originalname);
        }
    })
});

router.get('/', (req, res) => 
{
    res.render('upload', {"registered_email": req.session.registered_email});
});





router.post('/', upload.array('uploadFile', 1), 
function (req, res, next) 
{
    
    res.render('upload', {"registered_email": req.session.registered_email});

});

module.exports = router;