const express = require("express");


var router = express.Router();
const {
    addOrUpdateCharacter,
    getCharacters,
    deleteCharacter,
    deleteNote,
    getNotes,
} = require('../auth/controller_post');
   

router.get('/', async (req, res) => 
{
    try 
    {
        const notes = await getNotes();
        var notes2 = notes.Items;
        console.log(notes2);
        res.render('posts', {"registered_email": req.session.registered_email, notes2 });


    } catch (err) 
    {
        console.error(err);
        res.status(500).json({ err: 'Something went wrong' });

       

    }
   
});



router.delete('/posts/:id', async (req, res) => 
{
    const { id } = req.params;
    try
    {
        var result = res.json(await deleteNote(id));
        console.log(result);
    } catch (err) 
    {
        console.error(err);
        res.status(500).json({ err: 'Something went wrong' });
    }
});






module.exports = router;