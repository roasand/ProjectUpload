module.exports = {
    aws_config: {
        UserPoolId: 'us-east-1_AP4NI8VhY',
        ClientId: '11qjlcuaft1huce661h8na0b9l',
        region: 'us-east-1'

    }
}