global.fetch = require('node-fetch');
const config = require('../config/aws_config.js');
const AmazonCognitoIdentity = require('amazon-cognito-identity-js');

const poolData = {
    UserPoolId: config.aws_config.UserPoolId,
    ClientId: config.aws_config.ClientId
};
const userPool = new AmazonCognitoIdentity.CognitoUserPool(poolData);

/**
 * This function is used by the user for signing up a new account. 
 * @param {string} email 
 * @param {string} password 
 * @param {Function} callback - The callback that handles the response.
 */
exports.Signup = function (email, password, callback) {
    var attributeList = [];

    attributeList.push(new AmazonCognitoIdentity.CognitoUserAttribute({
        Name: "email",
        Value: email
    }));

    userPool.signUp(email, password, attributeList, null, function (err, result) {
        if (err) {
            callback(err);
        } else{
            var cognitoUser = result.user;
            callback(null, cognitoUser);
        }
    })
}


exports.Signin = function (email, password, callback) {
    var authenticationDetails = new AmazonCognitoIdentity.AuthenticationDetails({
        Username: email,
        Password: password
    });

    var cognitoUser = new AmazonCognitoIdentity.CognitoUser({
        Username: email,
        Pool: userPool
    });

    cognitoUser.authenticateUser(authenticationDetails, {
        onSuccess: (result) => {
            // var accesstoken = result.getAccessToken().getJwtToken();
            callback(null, result);
        },
        onFailure: (err) => {
            callback(err);
        },
    })
};


exports.Forgotpassword = function(email, callback) {
	
    var userPool = new AmazonCognitoIdentity.CognitoUserPool(poolData);
	
    var cognitoUser = new AmazonCognitoIdentity.CognitoUser({
        Username: email,
        Pool: userPool
    });
		
    cognitoUser.forgotPassword({
        onSuccess: (result) => {
            callback(null, result);
        },
        onFailure: (err) => {
			callback(err);
        }
    });
}


exports.Confirmpassword = function(verificationCode, email, newPassword, callback) {
	
    var userPool = new AmazonCognitoIdentity.CognitoUserPool(poolData);
	
    var cognitoUser = new AmazonCognitoIdentity.CognitoUser(
        {
        Username: email,
        Pool: userPool
    });
		
    cognitoUser.confirmPassword(verificationCode, newPassword, {
        onSuccess: (result) => {
            callback(null, result);
        },
        onFailure: (err) => {
			callback(err);
        }
    });
}
