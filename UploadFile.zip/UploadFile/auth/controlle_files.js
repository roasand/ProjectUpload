const AWS = require('aws-sdk');

AWS.config.update({region: 'us-east-1'});
s3 = new AWS.S3({apiVersion: '2006-03-01'});



const getFiles = async () => 
{

    const params = 
    {
       Bucket : 'media-uploadfinal',
    };
    const files = await s3.listObjects(params).promise();
    return files;
};



module.exports = 
{
    getFiles
 
};