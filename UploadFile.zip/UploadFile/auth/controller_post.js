const AWS = require('aws-sdk');

AWS.config.update(
  {
    region: 'us-east-1',
    accessKeyId: 'AKIAR57BUIFV3AW57GMS',
    secretAccessKey: '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',
});

const dynamoClient = new AWS.DynamoDB.DocumentClient();
const TABLE_NAME = 'notes';


const getNotes = async () => 
{
    const params = 
    {
        TableName: TABLE_NAME,
    };
    const notes = await dynamoClient.scan(params).promise();
    return notes;
};


const deleteNote = async (noteId) => 
{
  const params = 
  {
      TableName: TABLE_NAME,
      Key: 
      {
         noteId,
      },
  };
  return await dynamoClient.delete(params).promise();
};






module.exports = 
{
  dynamoClient,
  getNotes,
  deleteNote
 
};